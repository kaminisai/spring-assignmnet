package com.capgemini.model;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Question {

	private long questionId;
	private String question;
	private List<String> answersList;
	private Set<String> answersSet;
	private Map<Integer,String> answersMap;
	public Question()
	{
		
	}
	@Override
	public String toString() {
		return "Question [questionId=" + questionId + ", question=" + question + ", answersList=" + answersList
				+ ", answersSet=" + answersSet + ", answersMap=" + answersMap + "]";
	}
	public Question(long questionId, String question, List<String> answersList, Set<String> answersSet,
			Map<Integer, String> answersMap) {
		super();
		this.questionId = questionId;
		this.question = question;
		this.answersList = answersList;
		this.answersSet = answersSet;
		this.answersMap = answersMap;
	}
	public long getQuestionId() {
		return questionId;
	}
	public void setQuestionId(long questionId) {
		this.questionId = questionId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public List<String> getAnswersList() {
		return answersList;
	}
	public void setAnswersList(List<String> answersList) {
		this.answersList = answersList;
	}
	public Set<String> getAnswersSet() {
		return answersSet;
	}
	public void setAnswersSet(Set<String> answersSet) {
		this.answersSet = answersSet;
	}
	public Map<Integer, String> getAnswersMap() {
		return answersMap;
	}
	public void setAnswersMap(Map<Integer, String> answersMap) {
		this.answersMap = answersMap;
	}
	
	
}
